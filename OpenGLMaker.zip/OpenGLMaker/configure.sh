#! /bin/zsh

cmake -S . -B out/build

