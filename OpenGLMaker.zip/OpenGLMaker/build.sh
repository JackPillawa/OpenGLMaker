#! /bin/zsh

cd out/build; make
