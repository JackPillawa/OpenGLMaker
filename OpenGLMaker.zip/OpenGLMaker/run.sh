#! /bin/zsh

"./out/build/testBuild"
